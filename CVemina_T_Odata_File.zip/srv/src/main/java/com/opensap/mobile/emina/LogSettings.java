package com.opensap.mobile.emina;

public abstract class LogSettings {
    public static final boolean PRETTY_TRACING = true;
}
